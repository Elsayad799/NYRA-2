module ashokshau/tgmusic

go 1.26.4

require (
	github.com/AshokShau/gotdbot v0.9.5
	github.com/amarnathcjd/gogram v1.7.10
	github.com/joho/godotenv v1.5.1
	github.com/shirou/gopsutil/v3 v3.24.5
	go.mongodb.org/mongo-driver/v2 v2.9.1
)

require (
	github.com/ebitengine/purego v0.11.0 // indirect
	github.com/go-ole/go-ole v1.3.0 // indirect
	github.com/klauspost/compress v1.20.0 // indirect
	github.com/lufia/plan9stats v0.0.0-20260802145828-341c2f0c90b5 // indirect
	github.com/power-devops/perfstat v0.0.0-20260805114148-88456608a4f6 // indirect
	github.com/shoenig/go-m1cpu v0.2.2 // indirect
	github.com/stretchr/testify v1.12.0 // indirect
	github.com/tklauser/go-sysconf v0.4.0 // indirect
	github.com/tklauser/numcpus v0.12.0 // indirect
	github.com/xdg-go/pbkdf2 v1.0.0 // indirect
	github.com/xdg-go/scram v1.2.0 // indirect
	github.com/xdg-go/stringprep v1.0.4 // indirect
	github.com/youmark/pkcs8 v0.0.0-20240726163527-a2c0da244d78 // indirect
	github.com/yusufpapurcu/wmi v1.2.4 // indirect
	golang.org/x/crypto v0.57.0 // indirect
	golang.org/x/sync v0.23.0 // indirect
	golang.org/x/sys v0.48.0 // indirect
	golang.org/x/text v0.42.0 // indirect
)
